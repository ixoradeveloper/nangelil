---Instalation---
1. Login into your WordPress admin panel.
2. Go to Admin Panel->Plugins->Add New->Upload
3. Select codecanyon-zPXRqyOk-css3-responsive-wordpress-compare-pricing-tables.zip file
4. Activate plugin
5. In Settings submenu you'll find CSS3 Compare Pricing Tables position to manage plugin.